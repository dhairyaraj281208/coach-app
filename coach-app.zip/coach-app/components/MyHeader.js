import React, { Component } from 'react';
import { Header, Icon, Badge, Image } from 'react-native-elements';
import { View, Text, StyeSheet, Alert } from 'react-native';
import db from '../config';
import firebase from 'firebase';

export default class MyHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userId: firebase.auth().currentUser.email,
      value: '',
    };
  }

  getNumberOfUnreadNotifications() {
    db.collection('all_notifications')
      .where('notification_status', '==', 'unread')
      .where('targeted_user_id', '==', this.state.userId)
      .onSnapshot((snapshot) => {
        var unreadNotifications = snapshot.docs.map((doc) => doc.data());
        this.setState({
          value: unreadNotifications.length,
        });
      });
  }

  componentDidMount() {
    this.getNumberOfUnreadNotifications();
  }

  BellIconWithBadge = () => {
    return (
      <View>
        <Image
          source={require('../assets/notifcation1.png')}
          style={{ width: 20, height: 20 }}
          onPress={() => this.props.navigation.navigate('Notification')}
        />
        <Badge
          value={this.state.value}
          containerStyle={{ position: 'absolute', top: -4, right: -4 }}
        />
      </View>
    );
  };

  render() {
    return (
      <View>
      <Header
        leftComponent={
          <Icon
            name="bars"
            type="font-awesome"
            color="#ffffff"
            onPress={() => this.props.navigation.toggleDrawer()}
          />
        }
        centerComponent={{
          text: this.props.title,
          style: { color: '#ffffff', fontSize: 20, fontWeight: 'bold' },
        }}
        rightComponent={<this.BellIconWithBadge {...this.props} />}
        backgroundColor="#0f7dd6"
      />
      </View>
    );
  }
}
