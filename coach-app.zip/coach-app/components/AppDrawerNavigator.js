import React from 'react';
import {Image} from 'react-native'
import {createDrawerNavigator} from 'react-navigation-drawer';
import { AppTabNavigator } from './AppTabNavigator'
import CustomSidebarMenu  from './CustomSidebarMenu';
import SettingScreen from '../screens/SettingScreen';
import NotificationScreen from '../screens/NotificationsScreen';

import {Icon} from 'react-native-elements';


export const AppDrawerNavigator = createDrawerNavigator({
  Home : {
    screen : AppTabNavigator,
    navigationOptions:{
      drawerIcon :<Image source={require("../assets/home-icon.png")} style={{width:20, height:20}}/>,
    }
    },
  Notifications :{
    screen : NotificationScreen,
    navigationOptions:{
      drawerIcon :<Image source={require("../assets/notificationd.png")} style={{width:20, height:20}}/>,
      drawerLabel : "Notifications"
    }
  },
    Setting : {
      screen : SettingScreen,
      navigationOptions:{
        drawerIcon :<Image source={require("../assets/images.png")} style={{width:20, height:20}}/>,




        drawerLabel : "Settings"
      }
    }
},
  {
    contentComponent:CustomSidebarMenu
  },
  {
    initialRouteName : 'Home'
  })
