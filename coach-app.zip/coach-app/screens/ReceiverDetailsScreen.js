import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Card, Header, Icon } from 'react-native-elements';
import firebase from 'firebase';
import { RFValue } from 'react-native-responsive-fontsize';
import db from '../config.js';

export default class ReceiverDetailsScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userId: firebase.auth().currentUser.email,
      userName: '',
      receiverId: this.props.navigation.getParam('details')['username'],
      exchangeId: this.props.navigation.getParam('details')['exchangeId'],
      itemName: this.props.navigation.getParam('details')['item_name'],
      description: this.props.navigation.getParam('details')['description'],
      receiverName: '',
      receiverContact: '',
      receiverAddress: '',
      receiverRequestDocId: '',
      phoneNumber: this.props.navigation.getParam('details')['phoneNumber'],
      fee: this.props.navigation.getParam('details')['item_value'],
      achievements: this.props.navigation.getParam('details')['achievements'],
    };
  }

  getUserDetails = (userId) => {
    db.collection('users')
      .where('email_id', '==', userId)
      .get()
      .then((snapshot) => {
        snapshot.forEach((doc) => {
          console.log(doc.data().first_name);
          this.setState({
            userName: doc.data().first_name + ' ' + doc.data().last_name,
          });
        });
      });
  };

  getreceiverDetails() {
    console.log('receiver ', this.state.receiverId);
    db.collection('users')
      .where('username', '==', this.state.receiverId)
      .get()
      .then((snapshot) => {
        snapshot.forEach((doc) => {
          this.setState({
            receiverName: doc.data().first_name,
            receiverContact: doc.data().mobile_number,
            receiverAddress: doc.data().address,
          });
        });
      });

    db.collection('exchange_requests')
      .where('exchangeId', '==', this.state.exchangeId)
      .get()
      .then((snapshot) => {
        snapshot.forEach((doc) => {
          this.setState({ receiverRequestDocId: doc.id });
        });
      });
  }


  addNotification = () => {
    console.log('in the function ', this.state.rec);
    var message =
      this.state.userName + ' has shown interest in exchanging the item';
    db.collection('all_notifications').add({
      targeted_user_id: this.state.receiverId,
      donor_id: this.state.userId,
      exchangeId: this.state.exchangeId,
      item_name: this.state.itemName,
      date: firebase.firestore.FieldValue.serverTimestamp(),
      notification_status: 'unread',
      message: message,
    });
  };

  componentDidMount() {
    this.getreceiverDetails();
    this.getUserDetails(this.state.userId);
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={{ flex: 0.1 }}>
          <Header
            leftComponent={
              <Icon
                name="arrow-left"
                type="feather"
                color="#ffff"
                onPress={() => this.props.navigation.goBack()}
              />
            }
            centerComponent={{
              text: 'Coach Details',
              style: { color: '#ffff', fontSize: 20, fontWeight: 'bold' },
            }}
            backgroundColor="#0f7dd6"
          />
        </View>
        <View style={{ flex: 0.3, marginTop: RFValue(20), padding: 20 }}>
          <Card
            title={'Coach Information'}
            titleStyle={{ fontSize: 20 }}
            style={{ padding: 30 }}>
            <Text style={{ fontWeight: 'bold', margin: 10 }}>
              Name : {this.state.itemName}
            </Text>

            <Text style={{ fontWeight: 'bold', margin: 10 }}>
              Subjects : {this.state.description}
            </Text>

            <Text style={{ fontWeight: 'bold', margin: 10 }}>
              Contact: {this.state.phoneNumber}
            </Text>

            <Text style={{ fontWeight: 'bold', margin: 10 }}>
              Fee(perMonth): {this.state.fee}
            </Text>
            <Text style={{ fontWeight: 'bold', margin: 10 }}>
              Achievements: {this.state.achievements}
            </Text>
          </Card>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
