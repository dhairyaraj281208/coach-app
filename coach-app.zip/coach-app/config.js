import firebase from 'firebase';
require('@firebase/firestore')

var firebaseConfig = {
    apiKey: "AIzaSyBhRsNErpZezOZHJZR6H8Evn1BG1RVNp30",
    authDomain: "coach-app-43f4f.firebaseapp.com",
    projectId: "coach-app-43f4f",
    storageBucket: "coach-app-43f4f.appspot.com",
    messagingSenderId: "81709323068",
    appId: "1:81709323068:web:01a4e0880e3950bb634439"
  };
//Initialize Firebase

  firebase.initializeApp(firebaseConfig);

  export default firebase.firestore();
